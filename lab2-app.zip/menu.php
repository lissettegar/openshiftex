<nav class="navbar navbar-default" role="navigation">

<div class="navbar-header">
  <a class="navbar-brand" href="/"><img width="75" src="Logicalis_logo.png" /></a>
</div>

<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  <ul class="nav navbar-nav">
    <li>
      <br>
      <table> 
        <tr>
          <td width=100px>
           <a href="load.php">Load Test</a>
          </td>
          <td width=100px>
            <a href="load2.php">Stop Test</a>
          </td>
          <td width=100px>
            <a href="edit.php">Edit File</a>
          </td>
        </tr>
      </table>
    </li>
  </ul>
</div>

</nav>
