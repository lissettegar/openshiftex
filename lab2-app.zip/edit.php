<!DOCTYPE html>
<html>
  <head>
    <title>Edit File</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>

  <body>
    <div class="container">

      <div class="row">
    		<div class="col-md-12">
      <?php include('menu.php'); ?>
      <div class="jumbotron">

<form action="edit-file.php" method="POST">
    <input name="field1" type="text" />
    <input name="field2" type="text" />
    <input type="submit" name="submit" value="Guardar">
</form>

    </p>
    <p>
    </p>
  </div>
</div>
</div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
  </body>
</html>
